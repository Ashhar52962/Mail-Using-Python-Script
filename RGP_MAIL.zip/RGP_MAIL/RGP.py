#==================================Importing a module=============================#
from tkinter import *
import smtplib
import datetime
import csv
import os
#===================================Creating a window==============================#
root = Tk()

root.geometry("800x550")
root.configure(bg="grey")

head = Label(text="THIS EXE IS FOR SENDING AN RGP MAIL TO STORE", font=("aerial", 20, "bold"))
head.place(x=10, y=10, height=40, width=800)



#======================================Main Function================================#
def gui():

    # declaring a varibale to get a value by user input
    sndrmail = ""
    rcvrmail = ""
    paswd = ""
    subject = ""
    message = ""
    label = ""
    folder_path = ""
    cust = ""
    date = datetime.datetime.now()
    #============================Send Mail Button Function========================
    def var(frm_entry,pwd_entry,to_enrty,Sub_entry,msg_entry):

        global sndrmail,rcvrmail,paswd,subject,message,label,date
        sndrmail = frm_entry.get()
        paswd = pwd_entry.get()
        rcvrmail = to_entry.get()
        subject = Sub_entry.get()

        message = msg_entry.get("1.0","end-1c")
        raw_datetime = datetime.datetime.now()
        str_date = str(raw_datetime)
        date = str_date[:11]
        curr_directory = os.getcwd()


        try:
            mail = smtplib.SMTP('smtp.gmail.com',587)
            mail.starttls()
            mail.ehlo()
            mail.login(sndrmail,paswd)
            mail.sendmail(sndrmail,rcvrmail,("Subject: " + str(subject) + "\n\n" + str(message)))
            label = "Email send Successfully"
            customer = subject.split(" ")
            customer_1 = customer[-1]
            start_material = message.find("1")
            material = message[start_material:]

            list = [date,customer_1,material]
            with open("RGP.csv","a",newline="") as f:
                writer = csv.writer(f)
                writer.writerow(list)






        except Exception as a:
            print(a)
        finally:
            label_1 = label
            label_2 = Label(text=label_1, font=('aerial', 20, 'bold'))
            label_2.place(x=400, y=100, height=40, width=400)
            mail.quit()

#======================================GUI Creation=============================
        # creating a label and entry box for gui
    frm_mail_entry = StringVar()
    to_mail_entry = StringVar()
    pwd = StringVar()
    msg = StringVar()
    sub = StringVar()


#=======================================Sender GUI=================================
        # sender information
    frm_label = Label(root,text = "Sender Email:",bg = "grey",fg = "Black",font = ("aerial",14,"bold"))
    frm_label.place(x = 10, y = 50)
    frm_entry = Entry(root,textvariable = frm_mail_entry,justify = "left")
    frm_entry.place(x = 10 , y = 80, height = 30, width = 300)

    pwd_label = Label(root, text="Password:", bg="grey", fg="Black", font=("aerial", 14, "bold"))
    pwd_label.place(x=10, y=110)
    pwd_entry = Entry(root,textvariable = pwd,justify = "left",show = "*")
    pwd_entry.place(x = 10 , y = 140, height = 30, width = 300)

#======================================Reciever GUI================================

        # reciever information gui
    rcvr_label = Label(root, text="Reciever Mail:", bg="grey", fg="Black", font=("aerial", 14, "bold"))
    rcvr_label.place(x=10, y=170)

    to_entry = Entry(root,textvariable = to_mail_entry,justify = "left")
    to_entry.place(x = 10 , y = 200, height = 30, width = 300)


#=====================================Message and Subject GUI========================
        # message and subject gui
    sub_label = Label(root, text="Subject:", bg="grey", fg="Black", font=("aerial", 14, "bold"))
    sub_label.place(x=10, y=230)
    Sub_entry = Entry(root,textvariable = sub,justify = "left")
    Sub_entry.place(x = 10 ,y = 260, height = 40, width = 300)

    msg_label = Label(root, text="Message:", bg="grey", fg="Black", font=("aerial", 14, "bold"))
    msg_label.place(x=10, y=300)
    msg_entry =Text(root, height = 10, width = 37)
    msg_entry.place(x = 10, y = 330)




        # sender button gui
    send_button = Button(root, text = "Send Mail",command = lambda:var(frm_entry,pwd_entry,to_entry,Sub_entry,msg_entry))
    send_button.place(x = 20, y = 500,height = 40, width = 80)
    return subject,message



gui()

root.mainloop()

